# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from Biblioteca.Apps.models import*

# Register your models here.
admin.site.register(Libro)

admin.site.register(Alumno)

admin.site.register(Categorias)

admin.site.register(Autor)

admin.site.register(Profesor)

admin.site.register(Edicion)

admin.site.register(Visitante)


