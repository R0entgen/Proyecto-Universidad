from __future__ import unicode_literals

from django.db import models

import time


class Alumno(models.Model):
	
	cedula = models.IntegerField(primary_key=True, null=False, blank=False)
	
	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")

class Categorias(models.Model):

	nombre = models.CharField(max_length=20)

class Edicion(models.Model):

	nombre = models.CharField(max_length=10)

class Autor(models.Model):
	
	nombre = models.CharField(max_length=50)
	
	categoria_id = models.ForeignKey(Categorias)

class Libro(models.Model):

	simbologia = models.CharField(primary_key=True, max_length=20)## es max_length no max_lenght
	
	titulo_Libro = models.CharField(max_length=100)
	
	autor_id = models.ForeignKey(Autor)##definicion de many2one relacion
	
	Nombre_del_Autor = models.CharField(max_length=50)
	
	categoria_id = models.ForeignKey(Categorias)

	edicion_id = models.ForeignKey(Edicion)

	
class Profesor(models.Model):

	cedula = models.IntegerField(primary_key=True, null=False, blank=False)

	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")

	dedicacion = models.CharField(max_length=2)


class Visitante(models.Model):

	cedula = models.IntegerField(primary_key=True, null=False, blank=False)

	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")


class Usuarios(models.Model):

	usuario=models.TextField(unique=True)
	
	password=models.TextField(primary_key=True)