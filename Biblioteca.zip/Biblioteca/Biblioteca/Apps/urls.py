from django.conf.urls import *

from Biblioteca.Apps.views import *#Le decimos a Django que de este directorio importe el fichero views



urlpatterns = [  
    
    url( r'^$' , Login.as_view(), name= 'Login' ),
    # url( r'^libro/$', views, name='all-books'),
    url( r'^$', Libro.as_view(), name='Libro'),
    
    
#Le decimos a Django que de este directorio importe el fichero views
]
